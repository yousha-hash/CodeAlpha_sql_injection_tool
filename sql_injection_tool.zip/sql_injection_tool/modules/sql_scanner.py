import aiohttp

async def scan_for_sql_injection(url):
    payloads = ["'", "' OR '1'='1", "';--", '" OR "1"="1', "') OR ('1'='1"]
    
    async with aiohttp.ClientSession() as session:
        for payload in payloads:
            test_url = f"{url}?id={payload}"
            try:
                async with session.get(test_url, timeout=5) as resp:
                    text = await resp.text()
                    if "mysql" in text.lower() or "syntax" in text.lower() or "sql" in text.lower():
                        print(f"[!!] Possible SQL Injection at: {test_url}")
                        return
            except:
                pass
