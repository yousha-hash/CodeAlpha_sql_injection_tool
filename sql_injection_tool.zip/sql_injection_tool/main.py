import asyncio
from modules.subdomain_enum import enumerate_subdomains
from modules.dir_bruteforce import dir_bruteforce
from modules.sql_scanner import scan_for_sql_injection

async def main():
    target = input("Enter target domain (example.com): ").strip()

    print("\n[1] Subdomain Enumeration...")
    subdomains = await enumerate_subdomains(target)
    print(f"Found subdomains: {subdomains}")

    print("\n[2] Directory Bruteforce...")
    dirs = await dir_bruteforce(f"http://{target}")
    print(f"Found directories: {dirs}")

    print("\n[3] SQL Injection Scanner...")
    for url in dirs:
        await scan_for_sql_injection(url)

if __name__ == "__main__":
    asyncio.run(main())
