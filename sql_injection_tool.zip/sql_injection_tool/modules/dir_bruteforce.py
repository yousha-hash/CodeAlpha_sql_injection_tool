import asyncio
import aiohttp

async def check_dir(session, url):
    try:
        async with session.get(url, timeout=5) as resp:
            if resp.status == 200:
                print(f"[+] Found directory: {url}")
                return url
    except:
        pass
    return None

async def dir_bruteforce(base_url):
    dirs_found = []
    wordlist = ["admin", "login", "dashboard", "uploads", "images"]
    
    async with aiohttp.ClientSession() as session:
        tasks = [check_dir(session, f"{base_url}/{w}") for w in wordlist]
        results = await asyncio.gather(*tasks)
        dirs_found = [r for r in results if r]
    
    return dirs_found
