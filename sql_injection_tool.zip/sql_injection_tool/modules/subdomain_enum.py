import asyncio
import aiohttp

async def check_subdomain(session, subdomain):
    try:
        async with session.get(f"http://{subdomain}", timeout=5) as resp:
            if resp.status < 400:
                print(f"[+] Found: {subdomain}")
                return subdomain
    except:
        pass
    return None

async def enumerate_subdomains(domain):
    subdomains_found = []
    wordlist = ["www", "mail", "admin", "test", "dev", "api"]
    
    async with aiohttp.ClientSession() as session:
        tasks = [check_subdomain(session, f"{w}.{domain}") for w in wordlist]
        results = await asyncio.gather(*tasks)
        subdomains_found = [r for r in results if r]
    
    return subdomains_found
